package com.example.suminrangedemo;
public class SumInRangeDemo {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};  // Sample array
        int n = arr.length;
        int L = 1;  // Lower index of the range
        int R = 3;  // Upper index of the range

        int sum = findSum(arr, n, L, R);

        System.out.println("Sum of elements from " + L + " to " + R + ": " + sum);
    }

    static int findSum(int[] arr, int n, int L, int R) {
        // Handle invalid ranges
        if (L < 0 || L >= n || R < 0 || R >= n || L > R) {
            throw new IllegalArgumentException("Invalid range provided.");
        }

        // Calculate prefix sums for efficient range sum calculation
        int[] prefixSums = new int[n];
        prefixSums[0] = arr[0];
        for (int i = 1; i < n; i++) {
            prefixSums[i] = prefixSums[i - 1] + arr[i];
        }

        // Return the sum within the specified range
        return prefixSums[R] - (L > 0 ? prefixSums[L - 1] : 0);
    }
}

