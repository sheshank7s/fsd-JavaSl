package com.example.doublylinkedlist;
class Node {
    int data;
    Node next;
    Node prev;

    Node(int d) {
        data = d;
        next = null;
        prev = null;
    }
}

class DoublyLinkedList {
    Node head;

    // Function to insert a new node at the beginning
    void push(int new_data) {
        Node new_node = new Node(new_data);
        new_node.next = head;
        new_node.prev = null;
        if (head != null) {
            head.prev = new_node;
        }
        head = new_node;
    }

    // Function to traverse the list forward
    void printListForward() {
        Node temp = head;
        System.out.println("Forward Traversal:");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    // Function to traverse the list backward
    void printListBackward() {
        Node temp = head;
        if (temp == null) {
            return;
        }
        // Reach the last node
        while (temp.next != null) {
            temp = temp.next;
        }
        System.out.println("Backward Traversal:");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
        list.push(2);
        list.push(4);
        list.push(8);
        list.push(10);

        list.printListForward();
        list.printListBackward();
    }
}

