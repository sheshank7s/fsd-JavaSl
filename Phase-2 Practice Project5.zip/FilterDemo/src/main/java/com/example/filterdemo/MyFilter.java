package com.example.filterdemo; // Update the package name

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/MyServlet")
public class MyFilter implements Filter {
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
            throws IOException, ServletException {
        // Add your filtering logic here before the request reaches the servlet
        System.out.println("Filtering request before reaching MyServlet");

        // Continue the request/response chain
        chain.doFilter(request, response);

        // Add your filtering logic here after the servlet has processed the request
        System.out.println("Filtering response after MyServlet has processed the request");
    }

    public void init(FilterConfig fConfig) throws ServletException {
        // Initialization code if needed
    }

    public void destroy() {
        // Cleanup code if needed
    }
}