package com.example.trycatchdemo;
public class TryCatchDemo {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3};

        try {
            // Attempt to access an index out of bounds
            System.out.println("Accessing element at index 4: " + numbers[4]);
        } catch (ArrayIndexOutOfBoundsException e) {
            // Catch the exception and handle it gracefully
            System.out.println("Error: Array index out of bounds!");
            System.out.println("Exception message: " + e.getMessage());
        } finally {
            // This block always executes, regardless of whether an exception occurs
            System.out.println("This code will always run.");
        }
    }
}
