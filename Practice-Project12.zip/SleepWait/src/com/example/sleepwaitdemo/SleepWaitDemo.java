package com.example.sleepwaitdemo;
public class SleepWaitDemo {
    public static void main(String[] args) throws InterruptedException {
        ThreadSleepDemo threadSleep = new ThreadSleepDemo();
        ThreadWaitDemo threadWait = new ThreadWaitDemo();

        // Start both threads
        threadSleep.start();
        threadWait.start();

        // Wait for both threads to finish
        threadSleep.join();
        threadWait.join();

        System.out.println("Main thread finished");
    }
}

class ThreadSleepDemo extends Thread {
    @Override
    public void run() {
        System.out.println("ThreadSleepDemo started");

        try {
            // Pause for 5 seconds using sleep()
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("ThreadSleepDemo finished");
    }
}

class ThreadWaitDemo extends Thread {
    private Object lock = new Object();

    @Override
    public void run() {
        System.out.println("ThreadWaitDemo started");

        synchronized (lock) {
            try {
                // Wait for notification using wait()
                lock.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("ThreadWaitDemo resumed and finished");
    }
}