package com.example.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet") // Maps the servlet to the URL "/LoginServlet"
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username"); // Get username from request
        String password = request.getParameter("password"); // Get password from request

        // Replace with your actual validation logic (e.g., database lookup)
        if ("admin".equals(username) && "password123".equals(password)) {
            response.setContentType("text/html"); // Set response content type to HTML
            PrintWriter out = response.getWriter(); // Get a writer to send HTML response
            out.println("<h1>Login Successful!</h1>"); // Print success message
        } else {
            response.sendRedirect("login.html"); // Redirect to login page on failure
        }
    }
}
