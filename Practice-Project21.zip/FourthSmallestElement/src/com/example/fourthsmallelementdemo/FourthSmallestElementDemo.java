package com.example.fourthsmallelementdemo;
public class FourthSmallestElementDemo {
    public static void main(String[] args) {
        int[] arr = {12, 13, 5, 8, 2, 9};  // Unsorted array

        int fourthSmallest = findFourthSmallest(arr);

        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }

    static int findFourthSmallest(int[] arr) {
        // Use a custom logic to find the fourth smallest element without sorting
        int fourthSmallest = Integer.MAX_VALUE;  // Initialize with a large value
        for (int i = 0; i < 4; i++) {
            int smallest = Integer.MAX_VALUE;
            for (int j = 0; j < arr.length; j++) {
                if (arr[j] < smallest && arr[j] > fourthSmallest) {
                    smallest = arr[j];
                }
            }
            fourthSmallest = smallest;
        }
        return fourthSmallest;
    }
}

