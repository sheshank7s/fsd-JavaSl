package com.example.moviemagic;
import java.util.HashMap;
import java.util.Map;

public class SeatingArrangement {
    private Map<String, Boolean> seats;  // Map to represent seat availability

    public SeatingArrangement() {
        this.seats = new HashMap<>();
        initializeSeatingArrangement();
    }

    private void initializeSeatingArrangement() {
        for (char row = 'A'; row <= 'E'; row++) {
            for (int seatNum = 1; seatNum <= 5; seatNum++) {
                String seat = row + String.valueOf(seatNum);
                seats.put(seat, true); // true for available, false for booked
            }
        }
    }

    public void displaySeatingArrangement(String date, String showTime) {
        System.out.println("Seating Arrangement for " + date + " " + showTime + ":");
        seats.forEach((seat, available) -> {
            System.out.print(seat + "(" + (available ? "Available" : "Booked") + ") ");
            if (seat.charAt(1) == '5') {
                System.out.println(); // Move to the next row after seat '5'
            }
        });
    }

    public boolean isSeatAvailable(String seatSelection) {
        return seats.containsKey(seatSelection) && seats.get(seatSelection);
    }

    public boolean isValidSeatSelection(String seatSelection) {
        // Check if seat selection is valid (e.g., B1, B2, B6 or B1-B5)
        return seatSelection.matches("[A-E][1-5](-[A-E][1-5])?");
    }

    public void bookSeat(String seatSelection) {
        seats.put(seatSelection, false);
    }
}
