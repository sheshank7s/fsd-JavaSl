package com.example.moviemagic;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class FrontDesk {
    private String username;
    private String password;
    private Map<String, Integer> bookings;  // To store booking details: seat -> amount
    public FrontDesk(String username, String password) {
        this.username = username;
        this.password = password;
        this.bookings = new HashMap<>();
        }
    public boolean login(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }
    public void updatePassword(String newPassword) {
        password = newPassword;
        System.out.println("Password updated successfully.");
    }
    public void viewSeatingArrangement(SeatingArrangement seatingArrangement, String date, String showTime) {
        seatingArrangement.displaySeatingArrangement(date, showTime);
    }
    public void bookTicket(SeatingArrangement seatingArrangement, TicketBooking ticketBooking, String date, String showTime) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Enter seat selection (e.g., B1, B2, B6 or B1-B5):");
            String seatSelection = scanner.next().toUpperCase();
            if (seatingArrangement.isValidSeatSelection(seatSelection)) {
                if (seatingArrangement.isSeatAvailable(seatSelection)) {
                    ticketBooking.calculateAmount(seatingArrangement);
                    int amount = ticketBooking.getTotalAmount();
                    System.out.println("Total amount: Rs." + amount);
                    System.out.println("Confirm booking? (yes/no):");
                    String confirmation = scanner.next().toLowerCase();
                    if (confirmation.equals("yes")) {
                        seatingArrangement.bookSeat(seatSelection);
                        bookings.put(date + " " + showTime + " " + seatSelection, amount);
                        System.out.println("Booking confirmed. Enjoy the show!");
                    } else {
                        System.out.println("Booking canceled.");
                    }
                } else {
                    System.out.println("Seat not available. Booking failed.");
                }
            } else {
                System.out.println("Invalid seat selection. Booking failed.");
            }
        }}
    public void viewBookingStatus() {
        System.out.println("Booking Status:");
        bookings.forEach((booking, amount) -> {
            System.out.println("Booking: " + booking + ", Amount: Rs." + amount);
        });}}