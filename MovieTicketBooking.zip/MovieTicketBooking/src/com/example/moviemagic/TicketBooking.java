package com.example.moviemagic;
public class TicketBooking {
    private int totalAmount;

    public void calculateAmount(SeatingArrangement seatingArrangement) {
        // Dummy calculation for demonstration purposes, replace with actual logic
        totalAmount = 180; // Assuming a fixed ticket price for demonstration
    }

    public int getTotalAmount() {
        return totalAmount;
    }
}