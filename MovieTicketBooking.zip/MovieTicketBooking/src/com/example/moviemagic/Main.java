package com.example.moviemagic;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.println("Enter Front Desk username:");
            String username = scanner.next();
            System.out.println("Enter Front Desk password:");
            String password = scanner.next();
            FrontDesk frontDesk = new FrontDesk(username, password);
            SeatingArrangement seatingArrangement = new SeatingArrangement();
            TicketBooking ticketBooking = new TicketBooking();
            // Example usage
            if (frontDesk.login(username, password)) {
                System.out.println("Enter date and show time for seating arrangement:");
                String date = scanner.next();
                String showTime = scanner.next();
                System.out.println("Available movies:");
                // You can replace these movie names with your actual list of movies
                System.out.println("1. Tiger 3");
                System.out.println("2. Animal");
                System.out.println("3. Dunki");
                System.out.println("Select a movie (enter the number):");
                int movieSelection = scanner.nextInt();
                // Additional logic to associate the selected movie with the booking
                String selectedMovie = getMovieName(movieSelection);

                System.out.println("You selected: " + selectedMovie);

                frontDesk.viewSeatingArrangement(seatingArrangement, date, showTime);
                frontDesk.bookTicket(seatingArrangement, ticketBooking, date, showTime);
                frontDesk.viewBookingStatus();
            } else {
                System.out.println("Login failed. Invalid credentials.");
            }
        } finally {
            scanner.close(); // Close the scanner in the finally block to ensure it gets closed even if an exception occurs
        }
    }
    private static String getMovieName(int selection) {
        switch (selection) {
            case 1:
                return "Tiger 3";
            case 2:
                return "Animal";
            case 3:
                return "Dunki";
            default:
                return "Unknown Movie";
        }
    }
}