package com.example.cruddemo;
import java.io.*;

public class FileCRUDDemo {
    public static void main(String[] args) {
        // Create a file
        File file = new File("myFile.txt");
        try {
            if (file.createNewFile()) {
                System.out.println("File created successfully.");
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("Error creating file: " + e.getMessage());
        }

        // Write content to the file
        try (FileWriter writer = new FileWriter(file)) {
            writer.write("This is the content of my file.");
            System.out.println("Content written to file.");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }

        // Read content from the file
        try (FileReader reader = new FileReader(file)) {
            int character;
            StringBuilder content = new StringBuilder();
            while ((character = reader.read()) != -1) {
                content.append((char) character);
            }
            System.out.println("File content: " + content);
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }

        // Append content to the file
        try (FileWriter writer = new FileWriter(file, true)) { // Append mode
            writer.write("\nAdditional content added to the file.");
            System.out.println("Content appended to file.");
        } catch (IOException e) {
            System.out.println("Error appending to file: " + e.getMessage());
        }

        // Delete the file
        if (file.delete()) {
            System.out.println("File deleted successfully.");
        } else {
            System.out.println("Error deleting file.");
        }
    }
}