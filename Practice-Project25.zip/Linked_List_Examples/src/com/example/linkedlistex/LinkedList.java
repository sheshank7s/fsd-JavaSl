package com.example.linkedlistex;

class Node {
    int data;
    Node next;

    Node(int d) {
        data = d;
        next = null;
    }
}

class LinkedList {
    Node head;

    void sortedInsert(int new_data) {
        Node new_node = new Node(new_data);

        // Handle empty list or insertion before head
        if (head == null || new_data < head.data) {
            new_node.next = head;
            head = new_node;
            if (head.next == null) {  // Handle single-node list
                head.next = head;
            }
            return;
        }

        Node current = head;

        // Traverse to find the correct position for insertion
        while (current.next != null && current.next.data < new_data) {
            current = current.next;
        }

        new_node.next = current.next;
        current.next = new_node;

        // Handle insertion at the end (maintain circularity)
        if (new_node.next == null) {
            new_node.next = head;
        }
    }

    void printList() {
        Node temp = head;
        if (temp != null) {
            do {
                System.out.print(temp.data + " ");
                temp = temp.next;
            } while (temp != head);
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.sortedInsert(50);
        list.sortedInsert(30);
        list.sortedInsert(40);
        list.sortedInsert(10);
        list.sortedInsert(20);

        System.out.println("Circular Linked List:");
        list.printList();
    }
}

