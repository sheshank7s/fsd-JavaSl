package com.example.exponentialsearch;

import java.util.Arrays;

public class ExponentialSearch {

    public static void main(String[] args) {
        int[] sortedArray = {2, 5, 7, 9, 12, 15, 20, 25}; // Sorted array
        int target = 25;                                  // Value to search for

        int index = exponentialSearch(sortedArray, target);

        if (index != -1) {
            System.out.println("Target found at index: " + index);
        } else {
            System.out.println("Target not found in the array.");
        }
    }

    public static int exponentialSearch(int[] sortedArray, int target) {
        if (sortedArray[0] == target) {
            return 0; // Target found at first index
        }

        int i = 1;
        while (i < sortedArray.length && sortedArray[i] <= target) {
            i = i * 2; // Double the search range
        }

        return Arrays.binarySearch(sortedArray, i / 2, Math.min(i, sortedArray.length), target);
    }
}

