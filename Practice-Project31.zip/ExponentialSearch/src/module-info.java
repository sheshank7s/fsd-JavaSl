/**
 * 
 */
/**
 * 
 */
module ExponentialSearch {
}