package com.example.filehandlingdemo;
import java.io.*;

public class FileHandlingDemo {
    public static void main(String[] args) {
        // Create a file object
        File file = new File("myFile.txt");

        try {
            // Create the file if it doesn't exist
            if (!file.exists()) {
                file.createNewFile();
                System.out.println("File created successfully.");
            } else {
                System.out.println("File already exists.");
            }

            // Write content to the file
            FileWriter writer = new FileWriter(file);
            writer.write("This is the content of my file.");
            writer.close();
            System.out.println("Content written to file.");

            // Read content from the file
            FileReader reader = new FileReader(file);
            int character;
            StringBuilder content = new StringBuilder();
            while ((character = reader.read()) != -1) {
                content.append((char) character);
            }
            reader.close();
            System.out.println("File content: " + content);

            // Append content to the file
            writer = new FileWriter(file, true);  // Append mode
            writer.write("\nAdditional content added to the file.");
            writer.close();
            System.out.println("Content appended to file.");

            // Delete the file
            if (file.delete()) {
                System.out.println("File deleted successfully.");
            } else {
                System.out.println("Error deleting file.");
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

