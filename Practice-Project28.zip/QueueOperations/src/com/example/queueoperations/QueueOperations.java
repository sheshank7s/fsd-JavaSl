package com.example.queueoperations;
import java.util.LinkedList;
import java.util.Queue;

public class QueueOperations {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements (enqueue)
        queue.add(10);
        queue.add(20);
        queue.add(30);

        System.out.println("Queue elements: " + queue);

        // Remove elements (dequeue)
        int removedElement = queue.remove();
        System.out.println("Removed element: " + removedElement);
        System.out.println("Updated queue: " + queue);

        // Check if queue is empty
        boolean isEmpty = queue.isEmpty();
        System.out.println("Is queue empty? " + isEmpty);

        // Get the first element without removing it (peek)
        int firstElement = queue.peek();
        System.out.println("First element: " + firstElement);
        System.out.println("Queue remains unchanged: " + queue);
    }
}

