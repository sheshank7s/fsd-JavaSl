package com.example.stackoperations;
import java.util.Stack;

public class StackOperations {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Insert elements (push)
        stack.push(10);
        stack.push(20);
        stack.push(30);

        System.out.println("Stack elements: " + stack);

        // Remove elements (pop)
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);
        System.out.println("Updated stack: " + stack);

        // Check if stack is empty
        boolean isEmpty = stack.isEmpty();
        System.out.println("Is stack empty? " + isEmpty);

        // Get the top element without removing it (peek)
        int topElement = stack.peek();
        System.out.println("Top element: " + topElement);
        System.out.println("Stack remains unchanged: " + stack);
    }
}
