package com.example.synchdemo;
public class SynchronizationDemo {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();

        Thread thread1 = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                sharedResource.increment();
            }
        });

        Thread thread2 = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                sharedResource.decrement();
            }
        });

        thread1.start();
        thread2.start();

        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final value of counter: " + sharedResource.getCounter());
    }
}

class SharedResource {
    private int counter = 0;

    public synchronized void increment() {
        counter++;
        System.out.println("Thread " + Thread.currentThread().getName() + ": " + counter);
    }

    public synchronized void decrement() {
        counter--;
        System.out.println("Thread " + Thread.currentThread().getName() + ": " + counter);
    }

    public int getCounter() {
        return counter;
    }
}
