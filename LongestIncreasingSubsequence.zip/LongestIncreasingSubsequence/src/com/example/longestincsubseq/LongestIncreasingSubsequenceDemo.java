package com.example.longestincsubseq;

import java.util.Arrays;

public class LongestIncreasingSubsequenceDemo {
    public static void main(String[] args) {
        int[] arr = {10, 22, 9, 33, 21, 50, 41, 60};  // Sample array

        int length = lis(arr);
        System.out.println("Length of the longest increasing subsequence: " + length);
    }
    static int lis(int[] arr) {
        int n = arr.length;
        int[] lis_len = new int[n];  // Stores the length of LIS ending at each index
        int[] prev = new int[n];    // Stores the previous element in the LIS

        Arrays.fill(lis_len, 1);  // Initialize all LIS lengths to 1
        Arrays.fill(prev, -1);   // Initialize all previous elements to -1

        // Build the LIS lengths using dynamic programming
        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (arr[i] > arr[j] && lis_len[i] < lis_len[j] + 1) {
                    lis_len[i] = lis_len[j] + 1;
                    prev[i] = j;
                }
            }
        }
        // Find the maximum LIS length and its starting index
        int max_index = 0;
        for (int i = 1; i < n; i++) {
            if (lis_len[i] > lis_len[max_index]) {
                max_index = i;
            }
        }
        // Optional: Backtrack to construct the actual LIS
        // (You can uncomment this part if you need to print the LIS itself)
        /*
        int[] lis = new int[lis_len[max_index]];
        int k = lis_len[max_index] - 1;
        lis[k] = arr[max_index];
        k--;
        int j = max_index;
        while (prev[j] != -1) {
            lis[k] = arr[prev[j]];
            k--;
            j = prev[j];
        }
        System.out.println("Longest increasing subsequence: " + Arrays.toString(lis));
        */
        return lis_len[max_index];
    }
}