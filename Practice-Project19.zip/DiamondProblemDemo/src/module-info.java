/**
 * 
 */
/**
 * 
 */
module DiamondProblemDemo {
}