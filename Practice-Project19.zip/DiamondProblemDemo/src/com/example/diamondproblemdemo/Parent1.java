package com.example.diamondproblemdemo;
interface Parent1 {
    default void fun() {
        System.out.println("Parent1");
    }
}
