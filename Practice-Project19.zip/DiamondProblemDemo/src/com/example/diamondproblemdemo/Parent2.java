package com.example.diamondproblemdemo;
interface Parent2 {
    default void fun() {
        System.out.println("Parent2");
    }
}
