package com.example.diamondproblemdemo;
public class Main {
    public static void main(String[] args) {
        Child child = new Child();
        child.fun(); // Output: Parent1 (or Parent2 if you chose the other implementation)
    }
}
