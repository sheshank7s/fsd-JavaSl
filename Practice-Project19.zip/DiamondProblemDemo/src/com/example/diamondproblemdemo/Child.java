package com.example.diamondproblemdemo;
class Child implements Parent1, Parent2 {

    // Explicitly resolve the ambiguity
    @Override
    public void fun() {
        Parent1.super.fun(); // Or Parent2.super.fun() to choose the other implementation
    }
}

