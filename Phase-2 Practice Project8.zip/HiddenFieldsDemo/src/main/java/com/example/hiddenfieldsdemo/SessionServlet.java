package com.example.hiddenfieldsdemo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the current session
        HttpSession session = request.getSession(true);

        // Check if the session has an attribute for visit count
        Integer visitCount = (Integer) session.getAttribute("visitCount");

        // If visit count is null, it's a new session; set it to 1
        if (visitCount == null) {
            visitCount = 1;
        } else {
            // If visit count is not null, increment it
            visitCount++;
        }

        // Store the updated visit count in the session
        session.setAttribute("visitCount", visitCount);

        // Prepare the response
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Display visit count and create a hidden form field
        out.println("<html><body>");
        out.println("<h2>Session Tracking using Hidden Form Fields</h2>");
        out.println("<form action='SessionServlet' method='post'>");
        out.println("<input type='hidden' name='visitCount' value='" + visitCount + "'>");
        out.println("<p>Visit Count: " + visitCount + "</p>");
        out.println("<input type='submit' value='Increment Visit Count'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Forward the request to doGet for processing
        doGet(request, response);
    }
}