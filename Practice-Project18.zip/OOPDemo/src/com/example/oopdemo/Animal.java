package com.example.oopdemo;
public class Animal {

    // Encapsulation: private variables to hide data
    private String name;
    private int age;

    // Constructor: initializes the object's state
    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Methods: provide behavior
    public void eat() {
        System.out.println(name + " is eating.");
    }

    public void sleep() {
        System.out.println(name + " is sleeping.");
    }

    public void makeSound() {
        System.out.println("Generic animal sound"); // Abstract method
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
