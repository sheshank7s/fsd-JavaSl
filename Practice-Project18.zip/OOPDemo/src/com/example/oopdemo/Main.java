package com.example.oopdemo;
public class Main {

    public static void main(String[] args) {

        // Create objects of Animal and Dog classes
        Animal animal1 = new Animal("Generic Animal", 5);
        Dog dog1 = new Dog("Buddy", 3);

        // Demonstrate object behavior
        animal1.eat();
        animal1.sleep();
        animal1.makeSound();

        dog1.eat();
        dog1.sleep();
        dog1.makeSound(); // Polymorphism in action
    }
}

