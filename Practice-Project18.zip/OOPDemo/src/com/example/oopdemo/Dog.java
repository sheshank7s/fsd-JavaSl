package com.example.oopdemo;
class Dog extends Animal {
    // Inheritance: Inheriting properties and methods from Animal
    public Dog(String name, int age) {
        super(name, age); // Calling the parent constructor
    }

    // Overriding the makeSound() method for specific behavior
    @Override
    public void makeSound() {
        System.out.println("Woof!");
    }
}