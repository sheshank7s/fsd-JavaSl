package com.example.linkedlistdemo;
import java.util.Scanner;

class Node {
    int data;
    Node next;

    Node(int d) {
        data = d;
        next = null;
    }
}

class LinkedList {
    Node head;

    void deleteNode(int key) {
        Node temp = head, prev = null;

        if (temp != null && temp.data == key) {
            head = temp.next;  // Delete head node if key matches
            return;
        }

        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }

        if (temp == null) {
            System.out.println("Key not found");
            return;
        }

        prev.next = temp.next;  // Bypass the node to be deleted
    }

    void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.head = new Node(10);
        list.head.next = new Node(20);
        list.head.next.next = new Node(10);
        list.head.next.next.next = new Node(40);

        try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("Enter key to delete: ");
			int key = scanner.nextInt();

			System.out.println("Original list:");
			list.printList();

			list.deleteNode(key);
		}
        System.out.println("List after deletion:");
        list.printList();
    }
}
