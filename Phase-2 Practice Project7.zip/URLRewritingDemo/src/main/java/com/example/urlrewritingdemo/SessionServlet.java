package com.example.urlrewritingdemo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the current session
        HttpSession session = request.getSession(true);

        // Check if the session has an attribute for visit count
        Integer visitCount = (Integer) session.getAttribute("visitCount");

        // If visit count is null, it's a new session; set it to 1
        if (visitCount == null) {
            visitCount = 1;
        } else {
            // If visit count is not null, increment it
            visitCount++;
        }

        // Store the updated visit count in the session
        session.setAttribute("visitCount", visitCount);

        // Prepare the response
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Display visit count using URL rewriting
        out.println("<html><body>");
        out.println("<h2>Session Tracking using URL Rewriting</h2>");
        out.println("<p>Visit Count: " + visitCount + "</p>");
        out.println("<a href='" + response.encodeURL("SessionServlet") + "'>Refresh</a>");
        out.println("</body></html>");
    }
}
