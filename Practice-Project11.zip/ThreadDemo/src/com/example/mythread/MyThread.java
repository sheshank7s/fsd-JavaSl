package com.example.mythread;
public class MyThread extends Thread {

    @Override
    public void run() {
        // Thread code here
        System.out.println("Thread running (extended Thread class)");
    }
}

