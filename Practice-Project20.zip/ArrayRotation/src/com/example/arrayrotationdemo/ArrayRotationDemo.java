package com.example.arrayrotationdemo;
public class ArrayRotationDemo {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7};  // Original array
        int n = 5;                           // Number of rotations

        System.out.println("Original array:");
        printArray(arr);

        rotateArray(arr, n);

        System.out.println("\nArray after right rotation:");
        printArray(arr);
    }

    static void rotateArray(int[] arr, int n) {
        n = n % arr.length; // Handle cases where n is greater than or equal to array length
        for (int i = 0; i < n; i++) {
            int last = arr[arr.length - 1];
            for (int j = arr.length - 1; j > 0; j--) {
                arr[j] = arr[j - 1];
            }
            arr[0] = last;
        }
    }

    static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}

