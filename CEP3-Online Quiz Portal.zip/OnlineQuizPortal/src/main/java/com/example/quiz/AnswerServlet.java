package com.example.quiz;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/AnswerServlet")
public class AnswerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    // Database connection parameters
    private static final String DB_URL = "jdbc:mysql://localhost:3306/quizdb";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "sonu1997";  // Update with your MySQL password
    // SQL queries
    private static final String SQL_GET_ANSWERS = "SELECT * FROM answers WHERE question_id = ?";
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Answer> answers = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            // Retrieve question from session
            List<Question> questions = (List<Question>) request.getSession().getAttribute("questions");
            int currentQuestionIndex = (int) request.getSession().getAttribute("index");
            Question currentQuestion = questions.get(currentQuestionIndex);
            // Get answers for the current question
            try (PreparedStatement pstmt = conn.prepareStatement(SQL_GET_ANSWERS)) {
                pstmt.setInt(1, currentQuestion.getId());
                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        Answer answer = new Answer();
                        answer.setId(rs.getInt("id"));
                        answer.setQuestionId(rs.getInt("question_id"));
                        answer.setText(rs.getString("text"));
                        answers.add(answer);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        request.setAttribute("answers", answers);
        request.getRequestDispatcher("answer.jsp").forward(request, response);
    }
}