package com.example.binarysearch;
public class BinarySearch {

    public static void main(String[] args) {
        int[] sortedArray = {2, 5, 7, 9, 12, 15}; // Array must be sorted
        int target = 7;                           // Value to search for

        int index = binarySearch(sortedArray, target);

        if (index != -1) {
            System.out.println("Target found at index: " + index);
        } else {
            System.out.println("Target not found in the array.");
        }
    }

    public static int binarySearch(int[] sortedArray, int target) {
        int low = 0;
        int high = sortedArray.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2; // Prevent overflow

            if (sortedArray[mid] == target) {
                return mid;
            } else if (sortedArray[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1; // Target not found
    }
}

