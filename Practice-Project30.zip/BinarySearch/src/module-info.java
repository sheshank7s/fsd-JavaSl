/**
 * 
 */
/**
 * 
 */
module BinarySearch {
}